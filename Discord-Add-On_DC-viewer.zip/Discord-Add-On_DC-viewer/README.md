Cet add-on Discord pour pc vous permettra de détecter un dc instantanément et de savoir sur quels serveurs il se trouve.

Pour activer l'add-on :

1. Extrayez le dossier et lancer start.exe dedans
2. Attendez la fin du chargement puis fermez la fenêtre
3. Ouvrez discord, allez dans "Avancés" et cliquez sur Activer l'add-on DC viewer

Le serveur discord de support si jamais vous avez une question :
https://discord.gg/EWa6N4C7